"use client";

import { useState } from "react";

import styles from "./ProductAbout.module.css";
import { HiOutlinePencil } from "react-icons/hi";

import type { Producer } from "@/types/Producer";
import Dropdown from "@/components/ui/Dropdown/Dropdown";

import { Languages, Trash, Plus, Book } from "lucide-react";

interface ProductAboutProps {
  producer: Producer;
  canEdit: boolean;
}

interface FixedLanguages {
  portugues: string;
  ingles: string;
  espanhol: string;
}

interface OtherLanguage {
  name: string;
  level: string;
}

export default function ProductAbout({ producer, canEdit }: ProductAboutProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const [backup, setBackup] = useState<{
    bio: string;
    fixed: FixedLanguages;
    others: OtherLanguage[];
  } | null>(null);

  const handleEdit = () => {
    setBackup({
      bio,
      fixed: fixedLanguages,
      others: otherLanguages,
    });
    setIsEditing(true);
  };

  const handleCancel = () => {
    if (backup) {
      setBio(backup.bio);
      setFixedLanguages(backup.fixed);
      setOtherLanguages(backup.others);
    }
    setIsEditing(false);
  };

  const handleSave = async () => {
    setIsSaving(true);

    const payload = {
      profileId: producer.profile.id, // ID correto
      bio,
      languages: getAllLanguages(), // retorna array [{ name, level }]
    };

    try {
      const res = await fetch("/api/profile/about", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        throw new Error("Erro ao salvar dados");
      }

      // Sucesso: limpa backup e fecha edição
      setBackup(null);
      setIsEditing(false);
    } catch (err) {
      console.error("Erro ao salvar:", err);
      alert("Ocorreu um erro ao salvar as informações. Tente novamente.");
    } finally {
      setIsSaving(false);
    }
  };

  const [fixedLanguages, setFixedLanguages] = useState<FixedLanguages>({
    portugues:
      producer.profile.languages?.find((l) => l.name === "Português")?.level ||
      "",
    ingles:
      producer.profile.languages?.find((l) => l.name === "Inglês")?.level || "",
    espanhol:
      producer.profile.languages?.find((l) => l.name === "Espanhol")?.level ||
      "",
  });

  const [otherLanguages, setOtherLanguages] = useState<OtherLanguage[]>(
    producer.profile.languages?.filter(
      (l) => !["Português", "Inglês", "Espanhol"].includes(l.name)
    ) || []
  );

  const languagesLevels = ["Básico", "Avançado", "Fluente", "Nativo"];

  const addOtherLanguage = () => {
    const last = otherLanguages[otherLanguages.length - 1];
    if (last && !last.name && !last.level) {
      return;
    }
    setOtherLanguages((prev) => [...prev, { name: "", level: "" }]);
  };

  const removeOtherLanguage = (index: number) => {
    setOtherLanguages((prev) => prev.filter((_, i) => i !== index));
  };

  const updateOtherLanguageName = (index: number, name: string) => {
    setOtherLanguages((prev) =>
      prev.map((item, i) => (i === index ? { ...item, name } : item))
    );
  };

  const updateOtherLanguageLevel = (index: number, level: string) => {
    setOtherLanguages((prev) =>
      prev.map((item, i) => (i === index ? { ...item, level } : item))
    );
  };

  const getAllLanguages = () => {
    const all: { name: string; level: string }[] = [];
    if (fixedLanguages.portugues)
      all.push({ name: "Português", level: fixedLanguages.portugues });
    if (fixedLanguages.ingles)
      all.push({ name: "Inglês", level: fixedLanguages.ingles });
    if (fixedLanguages.espanhol)
      all.push({ name: "Espanhol", level: fixedLanguages.espanhol });
    otherLanguages.forEach((l) => {
      if (l.name && l.level) all.push(l);
    });
    return all;
  };

  const [bio, setBio] = useState(producer.profile.description || "");
  const [expanded, setExpanded] = useState(false);
  const MAX_LENGTH = 480;
  const previewText =
    bio && bio.length > MAX_LENGTH ? bio.slice(0, MAX_LENGTH) + "..." : bio;

  function renderParagraphs(text: string) {
    return text
      .split(/\n+/)
      .filter(Boolean)
      .map((p, i) => <p key={i}>{p}</p>);
  }

  return (
    <section className={styles.container}>
      <div className={styles.header}>
        <h2 className={styles.title}>Sobre Mim</h2>

        {canEdit ? (
          !isEditing ? (
            <button className={styles.editBtn} onClick={handleEdit}>
              Editar <HiOutlinePencil />
            </button>
          ) : (
            <div className={styles.editActions}>
              <button
                className={styles.saveBtn}
                onClick={handleSave}
                disabled={isSaving}
              >
                {isSaving ? "Salvando..." : "Salvar"}
              </button>

              <button
                className={styles.cancelBtn}
                onClick={handleCancel}
                disabled={isSaving}
              >
                Cancelar
              </button>
            </div>
          )
        ) : null}
      </div>

      {isSaving ? (
        <div className={styles.saving}>
          <span className={styles.spinner}></span>
        </div>
      ) : !isEditing ? (
        <div className={styles.bioContainer}>
          {bio ? (
            <>
              {expanded ? (
                <div className={styles.bio}>{renderParagraphs(bio)}</div>
              ) : (
                <div className={styles.bio}>
                  {renderParagraphs(previewText)}
                </div>
              )}

              {bio.length > MAX_LENGTH && (
                <button
                  className={styles.readMoreButton}
                  onClick={() => setExpanded(!expanded)}
                >
                  {expanded ? "Ler menos" : "Ler mais"}
                </button>
              )}
            </>
          ) : (
            <>
              {canEdit ? (
                <div className={styles.bio}>
                  <p style={{ opacity: "0.75" }}>
                    Adicione uma biografia e aproxime-se de seu público!
                  </p>
                </div>
              ) : (
                <p style={{ opacity: "0.75" }}>Não há biografia</p>
              )}
            </>
          )}
        </div>
      ) : (
        <textarea
          className={styles.textarea}
          value={bio}
          onChange={(e) => setBio(e.target.value)}
          placeholder="Conte um pouco sobre você..."
          rows={5}
        />
      )}
    </section>
  );
}
