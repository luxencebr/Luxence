"use client";

import type React from "react";

import { useRouter } from "next/navigation";

import { useEffect, useState, useRef, useMemo } from "react";
import styles from "./Signup.module.css";

import { FaMars, FaVenus, FaTransgender } from "react-icons/fa6";
import { FaEye, FaEyeSlash, FaCheck, FaTimes } from "react-icons/fa";
import { IoClose } from "react-icons/io5";

import Popup from "@/components/ui/Popup/Popup";
import register from "./register";

function PasswordRequirements({ password }: { password: string }) {
  const requirements = useMemo(
    () => [
      {
        label: "Deve conter ao menos 8 caracteres.",
        met: password.length >= 8,
      },
      {
        label: "Deve conter ao menos UMA maiúscula.",
        met: /[A-Z]/.test(password),
      },
      {
        label: "Deve conter ao menos UMA minúscula.",
        met: /[a-z]/.test(password),
      },
      { label: "Deve conter ao menos UM número.", met: /\d/.test(password) },
      {
        label: "Deve conter ao menos UM símbolo.",
        met: /[\W_]/.test(password),
      },
    ],
    [password],
  );

  // 🔹 Requisitos NÃO atendidos
  const unmetRequirements = requirements.filter((req) => !req.met);

  // 🔹 Se não digitou nada ou se todos foram atendidos, não renderiza nada
  if (!password || unmetRequirements.length === 0) return null;

  return (
    <div className={styles.passwordRequirements}>
      {unmetRequirements.map((req, index) => (
        <div
          key={index}
          className={`${styles.requirement} ${styles.requirementUnmet}`}
        >
          <FaTimes />
          <span>{req.label}</span>
        </div>
      ))}
    </div>
  );
}

export default function SignupPage() {
  const [isOpen, setIsOpen] = useState(false);

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [password, setPassword] = useState("");

  const [role, setRole] = useState<"CLIENT" | "ADVERTISER" | null>(null);

  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [success, setSuccess] = useState<string>("");

  const [isLoading, setIsLoading] = useState(false);
  const isFormDisabled = isLoading || success !== "";

  const formRef = useRef<HTMLFormElement>(null);

  const router = useRouter();

  useEffect(() => {
    if (!isOpen) {
      setErrors({});
      setSuccess("");
      setIsLoading(false);
      setShowPassword(false);
      setRole(null);
      setPassword(""); // Limpa senha ao fechar
      formRef.current?.reset();
    }
  }, [isOpen]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!role) return;

    const result = (await register(e, {
      setErrors,
      setSuccess,
      setIsLoading,
      role: role,
    })) as {
      ok: boolean;
      role?: "CLIENT" | "ADVERTISER";
      userId?: string;
      loginSuccess?: boolean;
    };

    // O setSuccess já foi chamado dentro do register, então a animação já está visível
    if (result.ok) {
      setTimeout(() => {
        setIsOpen(false);

        if (result.loginSuccess) {
          if (result.role === "ADVERTISER") {
            router.push(`/advertiser?uid=${result.userId}`);
          } else {
            router.refresh();
          }
        }
      }, 800);
    }
  };

  return (
    <Popup
      trigger={"Cadastre-se"}
      triggerClass={styles.trigger}
      popupClass={styles.popup}
      isOpen={isOpen}
      onOpenChange={setIsOpen}
    >
      {success ? (
        <div className={styles.successContainer}>
          <svg
            className={styles.checkmark}
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 52 52"
          >
            <circle
              className={styles.checkmarkCircle}
              cx="26"
              cy="26"
              r="25"
              fill="none"
            />
            <path
              className={styles.checkmarkCheck}
              fill="none"
              d="M14 27l7 7 16-16"
            />
          </svg>
          <p>{success}</p>
        </div>
      ) : (
        <div className={styles.formContent}>
          <div className={styles.formHeader}>
            <h1>Cadastre-se</h1>
            <button
              onClick={() => setIsOpen(false)}
              className={styles.closeButton}
            >
              <IoClose />
            </button>
          </div>

          <form
            ref={formRef}
            onSubmit={handleSubmit}
            className={`${styles.form} ${isFormDisabled ? styles.disabled : ""}`}
            aria-busy={isLoading}
          >
            <div className={styles.fieldsets}>
              <fieldset>
                <label htmlFor="name">
                  Nome:
                  <input
                    name="name"
                    id="name"
                    type="text"
                    placeholder="Seu nome..."
                    onChange={() => setErrors({})}
                  />
                </label>

                <label htmlFor="email">
                  Email:
                  <input
                    name="email"
                    id="email"
                    type="email"
                    placeholder="Seu email..."
                    onChange={() => setErrors({})}
                  />
                </label>

                <label htmlFor="password">
                  Senha:
                  <div className={styles.passwordWrapper}>
                    <input
                      name="password"
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Sua senha..."
                      onChange={(e) => {
                        setErrors({});
                        setPassword(e.target.value);
                      }}
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className={styles.showPasswordBtn}
                    >
                      {showPassword ? <FaEye /> : <FaEyeSlash />}
                    </button>
                  </div>
                </label>

                <label htmlFor="confirmPassword">
                  Confirmar senha:
                  <div className={styles.passwordWrapper}>
                    <input
                      name="confirmPassword"
                      id="confirmPassword"
                      type={showConfirmPassword ? "text" : "password"}
                      placeholder="Confirme a senha..."
                      onChange={() => setErrors({})}
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                      className={styles.showPasswordBtn}
                    >
                      {showConfirmPassword ? <FaEye /> : <FaEyeSlash />}
                    </button>
                  </div>
                </label>
                <PasswordRequirements password={password} />
              </fieldset>
              <fieldset>
                <h2>
                  Para melhorar a <br /> sua experiência!
                </h2>
                <span>Qual seu gênero?</span>
                <div className={styles.genderGroup}>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="MALE"
                      onChange={() => setErrors({})}
                    />
                    <span>
                      <i>
                        <FaMars />
                      </i>
                      Homem
                    </span>
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="FEMALE"
                      onChange={() => setErrors({})}
                    />
                    <span>
                      <i>
                        <FaVenus />
                      </i>
                      Mulher
                    </span>
                  </label>
                  <label>
                    <input
                      type="radio"
                      name="gender"
                      value="TRANS"
                      onChange={() => setErrors({})}
                    />
                    <span>
                      <i>
                        <FaTransgender />
                      </i>
                      Trans
                    </span>
                  </label>
                </div>
                <span>E seus interesses?</span>
                <div className={styles.genderGroup}>
                  <label>
                    <input
                      type="checkbox"
                      name="preferences"
                      value="MALE"
                      onChange={() => setErrors({})}
                    />
                    <span>
                      <i>
                        <FaMars />
                      </i>
                      Homem
                    </span>
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      name="preferences"
                      value="FEMALE"
                      onChange={() => setErrors({})}
                    />
                    <span>
                      <i>
                        <FaVenus />
                      </i>
                      Mulher
                    </span>
                  </label>
                  <label>
                    <input
                      type="checkbox"
                      name="preferences"
                      value="TRANS"
                      onChange={() => setErrors({})}
                    />
                    <span>
                      <i>
                        <FaTransgender />
                      </i>
                      Trans
                    </span>
                  </label>
                </div>
              </fieldset>
            </div>
            <div className={styles.buttonGroup}>
              <button
                type="submit"
                name="role"
                value="ADVERTISER"
                className={styles.advertiser}
                data-action="advertiser"
                disabled={isLoading}
                onClick={() => setRole("ADVERTISER")}
              >
                {isLoading && role === "ADVERTISER" ? (
                  <span className={styles.spinner}></span>
                ) : (
                  "Sou Anunciante"
                )}
              </button>

              <button
                type="submit"
                name="role"
                value="CLIENT"
                className={styles.client}
                data-action="client"
                disabled={isLoading}
                onClick={() => setRole("CLIENT")}
              >
                {isLoading && role === "CLIENT" ? (
                  <span className={styles.spinner}></span>
                ) : (
                  "Sou Cliente"
                )}
              </button>
            </div>
          </form>
        </div>
      )}
      <div className={styles.errors}>
        {errors.general && <p className={styles.error}>{errors.general}</p>}

        {errors.name && <p className={styles.error}>{errors.name}</p>}

        {errors.email && <p className={styles.error}>{errors.email}</p>}

        {errors.password && <p className={styles.error}>{errors.password}</p>}

        {errors.confirmPassword && (
          <p className={styles.error}>{errors.confirmPassword}</p>
        )}

        {errors.gender && <p className={styles.error}>{errors.gender}</p>}

        {errors.preferences && (
          <p className={styles.error}>{errors.preferences}</p>
        )}
      </div>
    </Popup>
  );
}
