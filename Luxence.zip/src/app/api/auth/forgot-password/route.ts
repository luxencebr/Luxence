import crypto from "crypto";
import { Resend } from "resend";
import { prisma } from "@/utils/prisma";

const resend = new Resend(process.env.RESEND_API_KEY);

export async function sendResetEmail(email: string, link: string) {
  await resend.emails.send({
    from: "Suporte <no-reply@seudominio.com>",
    to: email,
    subject: "Redefinição de senha",
    html: `
      <p>Você solicitou a redefinição da sua senha.</p>
      <p>
        <a href="${link}">
          Clique aqui para redefinir sua senha
        </a>
      </p>
      <p>Esse link expira em 30 minutos.</p>
    `,
  });
}

export async function POST(req: Request) {
  const { email } = await req.json();

  const user = await prisma.user.findUnique({
    where: { email },
  });

  // Segurança: nunca revela se existe
  if (!user) {
    return Response.json({ ok: true });
  }

  // invalida tokens antigos
  await prisma.passwordResetToken.deleteMany({
    where: { userId: user.id },
  });

  const rawToken = crypto.randomBytes(32).toString("hex");

  const hashedToken = crypto
    .createHash("sha256")
    .update(rawToken)
    .digest("hex");

  await prisma.passwordResetToken.create({
    data: {
      token: hashedToken,
      expiresAt: new Date(Date.now() + 1000 * 60 * 30), // 30 min
      userId: user.id,
    },
  });

  const resetLink = `${process.env.NEXTAUTH_URL}/reset-password?token=${rawToken}`;

  await sendResetEmail(user.email, resetLink);

  return Response.json({ ok: true });
}
