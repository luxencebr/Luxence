import { NextResponse } from "next/server";
import { prisma } from "@/utils/prisma";

export async function POST(req: Request) {
  try {
    const data = await req.json();
    const { userId } = data;

    if (!userId) {
      return NextResponse.json(
        { error: "userId é obrigatório." },
        { status: 400 },
      );
    }

    const cleanDocument = data.document?.replace(/\D/g, "");
    const existingProducer = await prisma.producer.findFirst({
      where: {
        OR: [{ document: data.document }, { document: cleanDocument }],
      },
    });

    if (existingProducer) {
      return NextResponse.json(
        { error: "Este documento já está cadastrado." },
        { status: 400 },
      );
    }

    const [day, month, year] = data.birthday.split("/");
    const birthday = new Date(`${year}-${month}-${day}`);

    if (
      !data.documentFrontPhoto ||
      !data.documentBackPhoto ||
      !data.selfieWithDocument
    ) {
      return NextResponse.json(
        { error: "Todas as fotos de documento são obrigatórias." },
        { status: 400 },
      );
    }

    const producer = await prisma.producer.create({
      data: {
        name: data.name,
        birthday,
        nationality: data.nationality,
        document: data.document,
        phone: data.phone,
        documentFrontPhoto: data.documentFrontPhoto,
        documentBackPhoto: data.documentBackPhoto,
        selfieWithDocument: data.selfieWithDocument,
        signature: "COPPER",
        user: {
          connect: { id: Number(data.userId) },
        },
        // Create empty profile to ensure data consistency
        profile: {
          create: {
            slogan: "",
            description: "",
            images: [],
            scholarity: "",
            languages: [],
            neighborhoods: [],
          },
        },
      },
      include: {
        profile: true,
      },
    });

    // Update user with locality information
    await prisma.user.update({
      where: { id: Number(data.userId) },
      data: {
        locality: {
          create: {
            country: "Brasil",
            state: "RJ",
            city: "Rio de Janeiro",
          },
        },
      },
    });

    return NextResponse.json({ producer }, { status: 201 });
  } catch (error: any) {
    console.error("[v0] Registration error:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
