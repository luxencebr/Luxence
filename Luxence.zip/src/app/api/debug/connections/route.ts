import { NextResponse } from "next/server";
import { prisma } from "@/utils/prisma";

export async function GET() {
  try {
    const activeConnections = await prisma.$queryRaw<
      Array<{ count: bigint }>
    >`SELECT count(*) FROM pg_stat_activity WHERE datname = current_database()`;

    const dbSize = await prisma.$queryRaw<
      Array<{ size: string }>
    >`SELECT pg_size_pretty(pg_database_size(current_database())) as size`;

    const slowQueries = await prisma.$queryRaw<
      Array<{ query: string; duration: number }>
    >`
      SELECT query, EXTRACT(EPOCH FROM (now() - query_start)) as duration
      FROM pg_stat_activity
      WHERE state = 'active'
      AND query NOT LIKE '%pg_stat_activity%'
      ORDER BY query_start
      LIMIT 10
    `;

    return NextResponse.json({
      connections: Number(activeConnections[0]?.count || 0),
      databaseSize: dbSize[0]?.size || "Unknown",
      slowQueries: slowQueries.map((q) => ({
        query: q.query.substring(0, 100),
        duration: Number(q.duration).toFixed(2) + "s",
      })),
      timestamp: new Date().toISOString(),
    });
  } catch (error) {
    return NextResponse.json(
      {
        error: "Failed to fetch database metrics",
        message: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 }
    );
  }
}
